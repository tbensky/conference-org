<?php

class Entry extends CI_Model 
{

public function get_json($entry_hash)
{

	/*
		var entry = {
					'year': year,
					'format': format,
					'title': title,
					'abstract': ab,
					'people': people,
					'talk_avail': talk_avail,
					'poster_avail': poster_avail
				};

	*/
	$q = $this->db->query("select * from entry where entry_hash=?",Array($entry_hash));	
	if ($q->num_rows() == 0)
		return(false);
	$row = $q->row_array();
	$row['people'] = json_decode($row['people'],true);
	return($row);
} 

function italics($x)
{
	$a = explode("[[",$x,2);
	if ($a[0] == $x)
		return($x);
	
	$b = explode("]]",$a[1],2);
	if ($b[0] == $a[1])
		return($a[1]);

	$y = $a[0] . "<i>" . $b[0] . "</i>" . $b[1];
	return($this->italics($y));
}


function get_entry_parts($json)
	{
		$entry = Array();
		$ret = "";
		
		$entry['title'] = $this->italics($json['title']);
		$entry['abstract'] = $this->italics($json['abstract']);

		$affil_list = Array();
		$people_list = Array();

		foreach($json['people'] as $p)
		{
			
			if ($p['affiliation'] != "Other...")
			{
				if ($p['affiliation'] == 'Kinesiology')
					$p['affiliation'] = 'Kinesiology and Public Health';
				if ($p['affiliation'] != 'School of Education')
					$affil = "Department of " . $p['affiliation'];
				else $affil = $p['affiliation'];
			}
			else $affil = $p['other_affiliation'];

			array_push($people_list,Array('name' => $p['name'],'affil' => $affil,'frost' => $p['frost']));
			array_push($affil_list,$affil);
		}

	
		$frost = "";
		$any_frost = false;

		$affil_list = array_values(array_unique($affil_list));
		$authors = "";
	
		$x = "";
		$aindex = "";
		
		foreach($people_list as $vals)
		{
			if ($vals['frost'] == 'yes')
			{
				$frost = "&dagger;";
				$any_frost = true;
			}

			$a = explode(",",$vals['name']);
			if (count($a) == 2)
			{
				$x .= $a[1] . " " . $a[0];
				$aindex .= $a[1] . " " . $a[0] . ",";
				$i = 1 + array_search($vals['affil'],$affil_list);
				if (count($affil_list) > 1)
					$x  .= "<sup>$i$frost</sup>, ";
				else $x .= "<sup>$frost</sup>, ";
			}
		}
		$ret .= rtrim($x,", ");
	
		$entry['people'] = $ret;	
		$entry['aindex'] = $aindex;

		$i = 1;
		$x = "";
		foreach ($affil_list as $value)
		{
			if (count($affil_list) > 1)
				$x .= "<sup>$i</sup> $value, ";
			else $x .= "$value, ";
			$i++;	
		}
		if ($any_frost)
			$x .= "<sup>&dagger;</sup>Frost Support";
		$x = rtrim($x,", ");

		$entry['affil'] = $x;
		return($entry);

	}



function gen_preview($json)
	{
		$entry = $this->get_entry_parts($json);
		$ret = "";
		
		$ret .= "<h2>" . $entry['title'] . "</h2>";
		$ret .= "<h4>" . $entry['people'] . "</h4>";
		$ret .= "<i>" . $entry['affil'] . "</i>";
		$ret .= "<br/><br/>";
		$ret .= $entry['abstract'];
		return($ret);

	}


/*
function gen_preview($json)
	{
		$ret = "";
		
		$title = $this->italics($json['title']);
		$abstract = $this->italics($json['abstract']);

		$ret .= "<h2>" . $title . "</h2>";
		$affil_list = Array();
		$people_list = Array();


		
		foreach($json['people'] as $p)
		{
			if ($p['affiliation'] != "Other...")
			{
				if ($p['affiliation'] == 'Kinesiology')
					$p['affiliation'] = 'Kinesiology and Public Health';
				if ($p['affiliation'] != 'School of Education')
					$affil = "Department of " . $p['affiliation'];
				else $affil = $p['affiliation'];
			}
			else $affil = $p['other_affiliation'];

			array_push($people_list,Array('name' => $p['name'],'affil' => $affil,'frost' => $p['frost']));
			array_push($affil_list,$affil);
		}

		//print_r($people_list);

		$frost = "";
		$any_frost = false;

		$affil_list = array_values(array_unique($affil_list));
		$authors = "";
		$ret .= "<h4>";
		$x = "";
		foreach($people_list as $vals)
		{
			if ($vals['frost'] == 'yes')
			{
				$frost = "<sup>&dagger;</sup>";
				$any_frost = true;
			}

			$a = explode(",",$vals['name']);
			if (count($a) == 2)
			{
				$x .= $a[1] . " " . $a[0];
				$i = 1 + array_search($vals['affil'],$affil_list);
				if (count($affil_list) > 1)
					$x  .= "<sup>$i$frost</sup>, ";
				else $x .= "$frost, ";
			}
		}
		$ret .= rtrim($x,", ");
		$ret .= "</h4>";
		

		$ret .= "<h4>";
		$i = 1;
		$x = "";
		foreach ($affil_list as $value)
		{
			if (count($affil_list) > 1)
				$x .= "<sup>$i</sup> $value, ";
			else $x .= "$value, ";
			$i++;	
		}
		if ($any_frost)
			$x .= "<sup>&dagger;</sup>Frost Support";
		$ret .= "</h4>";
		$ret .= "<i>" . rtrim($x,", ") . "</i>";

		$ret .= "<br/><br/>";

		$ret .= $abstract;
		return($ret);

	}
*/

	function list_all($q)
	{
		echo "<table class='table table-hover'>";
		foreach($q->result_array() as $row)
		{
			$json = $this->Entry->get_json($row['entry_hash']);
			echo "<tr><td>";
			echo anchor("start/crud_edit/" . $row['entry_hash'],'Edit',Array("class" => "btn btn-primary btn-xs"));
			echo "&nbsp; Preview link: <input value='";
			echo site_url("start/view/" . $row['entry_hash']);
			echo "' size=100>";
			echo "<p/>";
			echo $this->Entry->gen_preview($json);
			echo "</td></tr>";
		}
		echo "</table>";
	}

	function count_them()
	{
		$q = $this->db->query("select count(*) as count from entry where format='poster'");
		$row = $q->row_array();	
		$pc = $row['count'];

		$q = $this->db->query("select count(*) as count from entry where format='talk'");
		$row = $q->row_array();	
		$tc = $row['count'];
		return(Array('posters' => $pc,'talks' => $tc));
	}

	function get_talk_list()
	{
		$q = $this->db->query("select * from entry where format='talk' order by seq asc");
		echo "<table class='table'>";
		foreach($q->result_array() as $row)
		{
			echo "<tr><td>";
			echo $row['seq'] . ": ";
			echo "<button onclick=up('" . $row['entry_hash'] . "')>Up</button>";
			echo " ";
			echo "<button onclick=down('" . $row['entry_hash'] . "')>Down</button>";
			echo " ";

			$json = $this->Entry->get_json($row['entry_hash']);
			$entry = $this->Entry->get_entry_parts($json);
			echo $entry['title'] . ": " . $entry['people'];
			echo "</td></tr>";
		}
		echo "</table>";
	}
}


?>
