$(function(){
	$(".radio-uniform").uniform();	
});